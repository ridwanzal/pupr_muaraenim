<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-11-25 07:42:09 --> 404 Page Not Found: Img/pu.png
ERROR - 2018-11-25 07:42:09 --> 404 Page Not Found: Img/pu.png
