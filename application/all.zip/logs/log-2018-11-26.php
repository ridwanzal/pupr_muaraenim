<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-11-26 01:57:59 --> 404 Page Not Found: Img/pu.png
ERROR - 2018-11-26 02:21:41 --> Severity: error --> Exception: The model name you are loading is the name of a resource that is already being used: galeri /opt/lampp/htdocs/dinaspu/system/core/Loader.php 275
ERROR - 2018-11-26 02:22:30 --> Severity: error --> Exception: The model name you are loading is the name of a resource that is already being used: galeri /opt/lampp/htdocs/dinaspu/system/core/Loader.php 275
ERROR - 2018-11-26 02:27:16 --> Severity: error --> Exception: Class Galeri already exists and doesn't extend CI_Model /opt/lampp/htdocs/dinaspu/system/core/Loader.php 353
ERROR - 2018-11-26 02:27:22 --> Severity: error --> Exception: Class Galeri already exists and doesn't extend CI_Model /opt/lampp/htdocs/dinaspu/system/core/Loader.php 353
ERROR - 2018-11-26 02:28:46 --> Severity: error --> Exception: Class Galeri already exists and doesn't extend CI_Model /opt/lampp/htdocs/dinaspu/system/core/Loader.php 353
ERROR - 2018-11-26 02:31:24 --> Severity: error --> Exception: Class Galeri already exists and doesn't extend CI_Model /opt/lampp/htdocs/dinaspu/system/core/Loader.php 353
ERROR - 2018-11-26 02:43:15 --> Severity: Notice --> Undefined property: Galeri::$db /opt/lampp/htdocs/dinaspu/application/libraries/Galeri.php 45
ERROR - 2018-11-26 02:43:15 --> Severity: error --> Exception: Call to a member function get() on null /opt/lampp/htdocs/dinaspu/application/libraries/Galeri.php 45
ERROR - 2018-11-26 02:44:08 --> Severity: Notice --> Undefined property: Galeri::$table /opt/lampp/htdocs/dinaspu/application/libraries/Galeri.php 45
ERROR - 2018-11-26 02:44:08 --> Query error: No tables used - Invalid query: SELECT *
ERROR - 2018-11-26 02:44:37 --> Severity: error --> Exception: Cannot use object of type stdClass as array /opt/lampp/htdocs/dinaspu/application/views/ando/home.php 193
ERROR - 2018-11-26 02:45:33 --> Severity: Notice --> Undefined variable: get_galeri /opt/lampp/htdocs/dinaspu/application/views/ando/home.php 186
ERROR - 2018-11-26 02:45:33 --> Severity: error --> Exception: Call to a member function result() on null /opt/lampp/htdocs/dinaspu/application/views/ando/home.php 186
ERROR - 2018-11-26 02:45:36 --> Severity: Notice --> Undefined variable: get_galeri /opt/lampp/htdocs/dinaspu/application/views/ando/home.php 186
ERROR - 2018-11-26 02:45:36 --> Severity: error --> Exception: Call to a member function result() on null /opt/lampp/htdocs/dinaspu/application/views/ando/home.php 186
ERROR - 2018-11-26 02:45:49 --> Severity: error --> Exception: Cannot use object of type stdClass as array /opt/lampp/htdocs/dinaspu/application/views/ando/home.php 193
ERROR - 2018-11-26 02:46:54 --> Severity: error --> Exception: Cannot use object of type mysqli as array /opt/lampp/htdocs/dinaspu/application/views/ando/home.php 193
ERROR - 2018-11-26 02:47:26 --> Severity: Notice --> Undefined property: stdClass::$foto /opt/lampp/htdocs/dinaspu/application/views/ando/home.php 193
ERROR - 2018-11-26 02:47:26 --> Severity: Notice --> Undefined property: stdClass::$nama /opt/lampp/htdocs/dinaspu/application/views/ando/home.php 193
ERROR - 2018-11-26 02:47:26 --> Severity: Notice --> Undefined property: stdClass::$foto /opt/lampp/htdocs/dinaspu/application/views/ando/home.php 193
ERROR - 2018-11-26 02:47:26 --> Severity: Notice --> Undefined property: stdClass::$nama /opt/lampp/htdocs/dinaspu/application/views/ando/home.php 193
ERROR - 2018-11-26 04:10:00 --> Severity: error --> Exception: Cannot use object of type stdClass as array /opt/lampp/htdocs/dinaspu/application/views/ando/home.php 193
ERROR - 2018-11-26 04:11:34 --> Severity: error --> Exception: syntax error, unexpected '?>' /opt/lampp/htdocs/dinaspu/application/views/ando/home.php 194
ERROR - 2018-11-26 04:11:43 --> Severity: error --> Exception: syntax error, unexpected '?>' /opt/lampp/htdocs/dinaspu/application/views/ando/home.php 194
ERROR - 2018-11-26 04:12:09 --> Severity: error --> Exception: syntax error, unexpected '?>' /opt/lampp/htdocs/dinaspu/application/views/ando/home.php 194
ERROR - 2018-11-26 04:12:43 --> Severity: 4096 --> Object of class stdClass could not be converted to string /opt/lampp/htdocs/dinaspu/application/views/ando/home.php 193
ERROR - 2018-11-26 04:12:43 --> Severity: 4096 --> Object of class stdClass could not be converted to string /opt/lampp/htdocs/dinaspu/application/views/ando/home.php 193
ERROR - 2018-11-26 04:21:07 --> 404 Page Not Found: Berita/index
ERROR - 2018-11-26 04:33:11 --> Severity: error --> Exception: syntax error, unexpected end of file /opt/lampp/htdocs/dinaspu/application/views/ando/home.php 413
ERROR - 2018-11-26 04:33:41 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH) /opt/lampp/htdocs/dinaspu/application/views/ando/home.php 95
ERROR - 2018-11-26 04:33:58 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH) /opt/lampp/htdocs/dinaspu/application/views/ando/home.php 95
ERROR - 2018-11-26 04:52:03 --> Severity: Notice --> Undefined variable: max /opt/lampp/htdocs/dinaspu/application/libraries/Artikel.php 62
ERROR - 2018-11-26 04:52:03 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' at line 14 - Invalid query: SELECT artikel.artikel_id AS id,
	 artikel.artikel_judul AS judul,
	 artikel.artikel_isi AS isi,
	 artikel.artikel_tgl_posting AS tanggal,
	 artikel.artikel_tags as tags,
	 artikel.artikel_dibaca AS dibaca,
	 artikel.artikel_seo_url AS slug,
	 kategori.nama_kategori,
	 kategori.id_kategori as kategori,
	 user.nama_lengkap AS nama_admin,
	 user.id_user AS id_admin,
	 foto_artikel.nama_foto AS foto
	 FROM artikel,kategori,user,foto_artikel
	 WHERE artikel.artikel_kategori=7 AND artikel.artikel_status='publish' AND kategori.aktif='Y' AND kategori.terhapus='N' AND user.status_user='Y' AND user.terhapus='N' AND artikel.artikel_id_user=user.id_user AND artikel.artikel_kategori=kategori.id_kategori AND foto_artikel.id_foto=(SELECT CASE  foto_artikel.featured WHEN 'Y' THEN id_foto WHEN 'N' THEN id_foto END AS 'id_foto'  FROM foto_artikel WHERE foto_artikel.id_artikel=artikel.artikel_id ORDER BY featured ASC LIMIT 1) ORDER BY artikel.artikel_id DESC LIMIT 
	 
ERROR - 2018-11-26 04:52:27 --> Severity: Warning --> Invalid argument supplied for foreach() /opt/lampp/htdocs/dinaspu/application/views/ando/home.php 117
ERROR - 2018-11-26 04:52:40 --> Severity: Warning --> Invalid argument supplied for foreach() /opt/lampp/htdocs/dinaspu/application/views/ando/home.php 117
ERROR - 2018-11-26 04:54:49 --> Severity: Warning --> Invalid argument supplied for foreach() /opt/lampp/htdocs/dinaspu/application/views/ando/home.php 117
ERROR - 2018-11-26 04:55:44 --> Severity: Warning --> Invalid argument supplied for foreach() /opt/lampp/htdocs/dinaspu/application/views/ando/home.php 117
ERROR - 2018-11-26 05:07:44 --> Query error: Unknown column 'sesi_form' in 'field list' - Invalid query: INSERT INTO `foto_artikel` (`nama_foto`, `token_foto`, `sesi_form`, `id_user`) VALUES ('gedung-kantor-upt-dinas-pu-riau-di-kampar_20160329_190132.jpg', '0.3589398953587164', '8782261811', '0')
ERROR - 2018-11-26 05:09:57 --> Query error: Unknown column 'sesi_form' in 'field list' - Invalid query: INSERT INTO `foto_artikel` (`nama_foto`, `token_foto`, `sesi_form`, `id_user`) VALUES ('gedung-kantor-upt-dinas-pu-riau-di-kampar_20160329_1901321.jpg', '0.16845918212653044', '8782261811', '0')
ERROR - 2018-11-26 05:10:48 --> Query error: Unknown column 'sesi_form' in 'field list' - Invalid query: INSERT INTO `foto_artikel` (`nama_foto`, `token_foto`, `sesi_form`, `id_user`) VALUES ('logo_dinaspupr1.png', '0.6990542432224622', '8782261811', '0')
ERROR - 2018-11-26 05:11:25 --> Query error: Unknown column 'sesi_form' in 'field list' - Invalid query: INSERT INTO `foto_artikel` (`nama_foto`, `token_foto`, `sesi_form`, `id_user`) VALUES ('images.jpeg', '0.7357825076087637', '8782261811', '0')
ERROR - 2018-11-26 05:19:53 --> Severity: Notice --> Undefined index: slug /opt/lampp/htdocs/dinaspu/application/views/ando/home.php 89
ERROR - 2018-11-26 05:19:53 --> Severity: Notice --> Undefined index: judul /opt/lampp/htdocs/dinaspu/application/views/ando/home.php 89
ERROR - 2018-11-26 05:19:53 --> Severity: Notice --> Undefined index: slug /opt/lampp/htdocs/dinaspu/application/views/ando/home.php 89
ERROR - 2018-11-26 05:19:53 --> Severity: Notice --> Undefined index: judul /opt/lampp/htdocs/dinaspu/application/views/ando/home.php 89
ERROR - 2018-11-26 05:19:53 --> Severity: Notice --> Undefined index: slug /opt/lampp/htdocs/dinaspu/application/views/ando/home.php 89
ERROR - 2018-11-26 05:19:53 --> Severity: Notice --> Undefined index: judul /opt/lampp/htdocs/dinaspu/application/views/ando/home.php 89
ERROR - 2018-11-26 05:27:11 --> 404 Page Not Found: Data_infrastruktur/index
ERROR - 2018-11-26 05:49:38 --> 404 Page Not Found: Profil%20/dasar_hukum
ERROR - 2018-11-26 13:54:51 --> 404 Page Not Found: Img/pu.png
ERROR - 2018-11-26 13:54:51 --> 404 Page Not Found: Img/pu.png
