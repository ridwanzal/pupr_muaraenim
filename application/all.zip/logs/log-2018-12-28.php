<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-12-28 02:45:19 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 02:45:20 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 02:45:20 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 02:45:22 --> Severity: Notice --> Undefined variable: jabatan_kd /home/u164602079/public_html/dinaspu/application/views/ando/struktur_organisasi.php 30
ERROR - 2018-12-28 02:45:23 --> Severity: Notice --> Undefined variable: jabatan_kd /home/u164602079/public_html/dinaspu/application/views/ando/struktur_organisasi.php 30
ERROR - 2018-12-28 02:45:23 --> Severity: Notice --> Undefined variable: jabatan_kd /home/u164602079/public_html/dinaspu/application/views/ando/struktur_organisasi.php 30
ERROR - 2018-12-28 02:45:23 --> Severity: Notice --> Undefined variable: jabatan_kd /home/u164602079/public_html/dinaspu/application/views/ando/struktur_organisasi.php 30
ERROR - 2018-12-28 02:45:23 --> Severity: Notice --> Undefined variable: jabatan_kd /home/u164602079/public_html/dinaspu/application/views/ando/struktur_organisasi.php 30
ERROR - 2018-12-28 02:45:23 --> Severity: Notice --> Undefined variable: jabatan_kd /home/u164602079/public_html/dinaspu/application/views/ando/struktur_organisasi.php 30
ERROR - 2018-12-28 02:45:23 --> Severity: Notice --> Undefined variable: jabatan_kd /home/u164602079/public_html/dinaspu/application/views/ando/struktur_organisasi.php 30
ERROR - 2018-12-28 02:45:23 --> Severity: Notice --> Undefined variable: jabatan_kd /home/u164602079/public_html/dinaspu/application/views/ando/struktur_organisasi.php 30
ERROR - 2018-12-28 02:45:23 --> Severity: Notice --> Undefined variable: jabatan_kd /home/u164602079/public_html/dinaspu/application/views/ando/struktur_organisasi.php 30
ERROR - 2018-12-28 02:45:23 --> Severity: Notice --> Undefined variable: jabatan_kd /home/u164602079/public_html/dinaspu/application/views/ando/struktur_organisasi.php 30
ERROR - 2018-12-28 02:45:23 --> Severity: Notice --> Undefined variable: jabatan_kd /home/u164602079/public_html/dinaspu/application/views/ando/struktur_organisasi.php 30
ERROR - 2018-12-28 02:45:23 --> Severity: Notice --> Undefined variable: jabatan_kd /home/u164602079/public_html/dinaspu/application/views/ando/struktur_organisasi.php 30
ERROR - 2018-12-28 02:45:23 --> Severity: Notice --> Undefined variable: jabatan_kd /home/u164602079/public_html/dinaspu/application/views/ando/struktur_organisasi.php 30
ERROR - 2018-12-28 02:45:23 --> Severity: Notice --> Undefined variable: jabatan_kd /home/u164602079/public_html/dinaspu/application/views/ando/struktur_organisasi.php 30
ERROR - 2018-12-28 02:45:23 --> Severity: Notice --> Undefined variable: jabatan_kd /home/u164602079/public_html/dinaspu/application/views/ando/struktur_organisasi.php 30
ERROR - 2018-12-28 02:45:23 --> Severity: Notice --> Undefined variable: jabatan_kd /home/u164602079/public_html/dinaspu/application/views/ando/struktur_organisasi.php 30
ERROR - 2018-12-28 02:45:23 --> Severity: Notice --> Undefined variable: jabatan_kd /home/u164602079/public_html/dinaspu/application/views/ando/struktur_organisasi.php 30
ERROR - 2018-12-28 02:45:23 --> Severity: Notice --> Undefined variable: jabatan_kd /home/u164602079/public_html/dinaspu/application/views/ando/struktur_organisasi.php 30
ERROR - 2018-12-28 02:45:23 --> Severity: Notice --> Undefined variable: jabatan_kd /home/u164602079/public_html/dinaspu/application/views/ando/struktur_organisasi.php 30
ERROR - 2018-12-28 02:45:23 --> Severity: Notice --> Undefined variable: jabatan_kd /home/u164602079/public_html/dinaspu/application/views/ando/struktur_organisasi.php 30
ERROR - 2018-12-28 02:45:23 --> Severity: Notice --> Undefined variable: jabatan_kd /home/u164602079/public_html/dinaspu/application/views/ando/struktur_organisasi.php 30
ERROR - 2018-12-28 02:45:23 --> Severity: Notice --> Undefined variable: jabatan_kd /home/u164602079/public_html/dinaspu/application/views/ando/struktur_organisasi.php 30
ERROR - 2018-12-28 02:45:23 --> Severity: Notice --> Undefined variable: jabatan_kd /home/u164602079/public_html/dinaspu/application/views/ando/struktur_organisasi.php 30
ERROR - 2018-12-28 02:45:23 --> Severity: Notice --> Undefined variable: jabatan_kd /home/u164602079/public_html/dinaspu/application/views/ando/struktur_organisasi.php 30
ERROR - 2018-12-28 02:45:23 --> Severity: Notice --> Undefined variable: jabatan_kd /home/u164602079/public_html/dinaspu/application/views/ando/struktur_organisasi.php 30
ERROR - 2018-12-28 02:45:23 --> Severity: Notice --> Undefined variable: jabatan_kd /home/u164602079/public_html/dinaspu/application/views/ando/struktur_organisasi.php 30
ERROR - 2018-12-28 02:45:23 --> Severity: Notice --> Undefined variable: jabatan_kd /home/u164602079/public_html/dinaspu/application/views/ando/struktur_organisasi.php 30
ERROR - 2018-12-28 02:45:23 --> Severity: Notice --> Undefined variable: jabatan_kd /home/u164602079/public_html/dinaspu/application/views/ando/struktur_organisasi.php 30
ERROR - 2018-12-28 02:45:23 --> Severity: Notice --> Undefined variable: jabatan_kd /home/u164602079/public_html/dinaspu/application/views/ando/struktur_organisasi.php 30
ERROR - 2018-12-28 02:45:23 --> Severity: Notice --> Undefined variable: jabatan_kd /home/u164602079/public_html/dinaspu/application/views/ando/struktur_organisasi.php 30
ERROR - 2018-12-28 02:45:23 --> Severity: Notice --> Undefined variable: jabatan_kd /home/u164602079/public_html/dinaspu/application/views/ando/struktur_organisasi.php 30
ERROR - 2018-12-28 02:45:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 02:45:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 02:45:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 02:45:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 02:45:48 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 02:45:48 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 02:45:48 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 02:47:13 --> Severity: Notice --> Undefined index: jabatan_nip /home/u164602079/public_html/dinaspu/application/views/ando/struktur_organisasi.php 36
ERROR - 2018-12-28 02:47:13 --> Severity: Notice --> Undefined index: jabatan_nip /home/u164602079/public_html/dinaspu/application/views/ando/struktur_organisasi.php 36
ERROR - 2018-12-28 02:47:13 --> Severity: Notice --> Undefined index: jabatan_nip /home/u164602079/public_html/dinaspu/application/views/ando/struktur_organisasi.php 36
ERROR - 2018-12-28 02:47:13 --> Severity: Notice --> Undefined index: jabatan_nip /home/u164602079/public_html/dinaspu/application/views/ando/struktur_organisasi.php 36
ERROR - 2018-12-28 02:47:13 --> Severity: Notice --> Undefined index: jabatan_nip /home/u164602079/public_html/dinaspu/application/views/ando/struktur_organisasi.php 36
ERROR - 2018-12-28 02:47:13 --> Severity: Notice --> Undefined index: jabatan_nip /home/u164602079/public_html/dinaspu/application/views/ando/struktur_organisasi.php 36
ERROR - 2018-12-28 02:47:13 --> Severity: Notice --> Undefined index: jabatan_nip /home/u164602079/public_html/dinaspu/application/views/ando/struktur_organisasi.php 36
ERROR - 2018-12-28 02:47:13 --> Severity: Notice --> Undefined index: jabatan_nip /home/u164602079/public_html/dinaspu/application/views/ando/struktur_organisasi.php 36
ERROR - 2018-12-28 02:47:13 --> Severity: Notice --> Undefined index: jabatan_nip /home/u164602079/public_html/dinaspu/application/views/ando/struktur_organisasi.php 36
ERROR - 2018-12-28 02:47:13 --> Severity: Notice --> Undefined index: jabatan_nip /home/u164602079/public_html/dinaspu/application/views/ando/struktur_organisasi.php 36
ERROR - 2018-12-28 02:47:13 --> Severity: Notice --> Undefined index: jabatan_nip /home/u164602079/public_html/dinaspu/application/views/ando/struktur_organisasi.php 36
ERROR - 2018-12-28 02:47:13 --> Severity: Notice --> Undefined index: jabatan_nip /home/u164602079/public_html/dinaspu/application/views/ando/struktur_organisasi.php 36
ERROR - 2018-12-28 02:47:13 --> Severity: Notice --> Undefined index: jabatan_nip /home/u164602079/public_html/dinaspu/application/views/ando/struktur_organisasi.php 36
ERROR - 2018-12-28 02:47:13 --> Severity: Notice --> Undefined index: jabatan_nip /home/u164602079/public_html/dinaspu/application/views/ando/struktur_organisasi.php 36
ERROR - 2018-12-28 02:47:13 --> Severity: Notice --> Undefined index: jabatan_nip /home/u164602079/public_html/dinaspu/application/views/ando/struktur_organisasi.php 36
ERROR - 2018-12-28 02:47:13 --> Severity: Notice --> Undefined index: jabatan_nip /home/u164602079/public_html/dinaspu/application/views/ando/struktur_organisasi.php 36
ERROR - 2018-12-28 02:47:13 --> Severity: Notice --> Undefined index: jabatan_nip /home/u164602079/public_html/dinaspu/application/views/ando/struktur_organisasi.php 36
ERROR - 2018-12-28 02:47:13 --> Severity: Notice --> Undefined index: jabatan_nip /home/u164602079/public_html/dinaspu/application/views/ando/struktur_organisasi.php 36
ERROR - 2018-12-28 02:47:13 --> Severity: Notice --> Undefined index: jabatan_nip /home/u164602079/public_html/dinaspu/application/views/ando/struktur_organisasi.php 36
ERROR - 2018-12-28 02:47:13 --> Severity: Notice --> Undefined index: jabatan_nip /home/u164602079/public_html/dinaspu/application/views/ando/struktur_organisasi.php 36
ERROR - 2018-12-28 02:47:13 --> Severity: Notice --> Undefined index: jabatan_nip /home/u164602079/public_html/dinaspu/application/views/ando/struktur_organisasi.php 36
ERROR - 2018-12-28 02:47:13 --> Severity: Notice --> Undefined index: jabatan_nip /home/u164602079/public_html/dinaspu/application/views/ando/struktur_organisasi.php 36
ERROR - 2018-12-28 02:47:13 --> Severity: Notice --> Undefined index: jabatan_nip /home/u164602079/public_html/dinaspu/application/views/ando/struktur_organisasi.php 36
ERROR - 2018-12-28 02:47:13 --> Severity: Notice --> Undefined index: jabatan_nip /home/u164602079/public_html/dinaspu/application/views/ando/struktur_organisasi.php 36
ERROR - 2018-12-28 02:47:13 --> Severity: Notice --> Undefined index: jabatan_nip /home/u164602079/public_html/dinaspu/application/views/ando/struktur_organisasi.php 36
ERROR - 2018-12-28 02:47:13 --> Severity: Notice --> Undefined index: jabatan_nip /home/u164602079/public_html/dinaspu/application/views/ando/struktur_organisasi.php 36
ERROR - 2018-12-28 02:47:13 --> Severity: Notice --> Undefined index: jabatan_nip /home/u164602079/public_html/dinaspu/application/views/ando/struktur_organisasi.php 36
ERROR - 2018-12-28 02:47:13 --> Severity: Notice --> Undefined index: jabatan_nip /home/u164602079/public_html/dinaspu/application/views/ando/struktur_organisasi.php 36
ERROR - 2018-12-28 02:47:13 --> Severity: Notice --> Undefined index: jabatan_nip /home/u164602079/public_html/dinaspu/application/views/ando/struktur_organisasi.php 36
ERROR - 2018-12-28 02:47:13 --> Severity: Notice --> Undefined index: jabatan_nip /home/u164602079/public_html/dinaspu/application/views/ando/struktur_organisasi.php 36
ERROR - 2018-12-28 02:47:13 --> Severity: Notice --> Undefined index: jabatan_nip /home/u164602079/public_html/dinaspu/application/views/ando/struktur_organisasi.php 36
ERROR - 2018-12-28 02:47:13 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 02:47:13 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 02:47:13 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 02:47:14 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 02:47:14 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 02:47:34 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 02:47:34 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 02:47:34 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 02:47:34 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 02:47:34 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 02:49:16 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 02:54:34 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 02:54:34 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 02:54:34 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 02:54:34 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 02:54:34 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 02:54:40 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 02:54:40 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 02:54:40 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 02:54:40 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 02:54:40 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 02:55:01 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 02:55:01 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 02:55:01 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 02:55:01 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 02:55:01 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 02:55:22 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 02:55:22 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 02:55:22 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 02:55:22 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 02:55:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 02:56:31 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 02:56:32 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 02:56:32 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 02:56:32 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 02:56:32 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 02:56:35 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 02:56:35 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 02:56:35 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 02:56:35 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 02:56:35 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 02:57:35 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 02:57:35 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 02:57:35 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 02:57:35 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 02:57:35 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 02:57:49 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 02:57:49 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 02:57:49 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 02:57:50 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 02:57:50 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 02:58:59 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 02:58:59 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 02:58:59 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 02:59:00 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 02:59:00 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 02:59:02 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 02:59:02 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 02:59:02 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 02:59:02 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 02:59:02 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 02:59:09 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 02:59:09 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 02:59:09 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 02:59:09 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 02:59:09 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 02:59:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 02:59:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 02:59:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 02:59:25 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 02:59:25 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:02:39 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:02:39 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:02:39 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:02:39 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:02:40 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:02:44 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:02:44 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:02:44 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:02:44 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:02:44 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:02:51 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:02:52 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:02:52 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:02:52 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:03:46 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:03:46 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:03:46 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:03:47 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:03:47 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:05:12 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:05:12 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:05:12 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:05:13 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:05:13 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:05:39 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:05:39 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:05:39 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:05:39 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:05:39 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:05:49 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:05:49 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:05:49 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:05:49 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:05:49 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:14:19 --> Severity: error --> Exception: Class Struktur_organisasi already exists and doesn't extend CI_Model /home/u164602079/public_html/dinaspu/system/core/Loader.php 353
ERROR - 2018-12-28 03:14:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2018-12-28 03:15:12 --> Severity: Error --> Class 'CI_Model' not found /home/u164602079/public_html/dinaspu/application/controllers/Struktur_organisasi.php 4
ERROR - 2018-12-28 03:15:21 --> Severity: error --> Exception: Class Struktur_organisasi already exists and doesn't extend CI_Model /home/u164602079/public_html/dinaspu/system/core/Loader.php 353
ERROR - 2018-12-28 03:15:49 --> Severity: error --> Exception: Class Struktur_organisasi already exists and doesn't extend CI_Model /home/u164602079/public_html/dinaspu/system/core/Loader.php 353
ERROR - 2018-12-28 03:16:14 --> Severity: error --> Exception: Class Struktur_organisasi already exists and doesn't extend CI_Model /home/u164602079/public_html/dinaspu/system/core/Loader.php 353
ERROR - 2018-12-28 03:17:28 --> Severity: Notice --> Undefined property: Struktur_organisasi::$Struktur_orgnasisasi /home/u164602079/public_html/dinaspu/application/controllers/Struktur_organisasi.php 27
ERROR - 2018-12-28 03:17:28 --> Severity: error --> Exception: Call to a member function get_data() on null /home/u164602079/public_html/dinaspu/application/controllers/Struktur_organisasi.php 27
ERROR - 2018-12-28 03:17:43 --> Severity: Notice --> Undefined property: Struktur_organisasi::$Struktur_orgnasisasi /home/u164602079/public_html/dinaspu/application/controllers/Struktur_organisasi.php 22
ERROR - 2018-12-28 03:17:43 --> Severity: error --> Exception: Call to a member function get_data() on null /home/u164602079/public_html/dinaspu/application/controllers/Struktur_organisasi.php 22
ERROR - 2018-12-28 03:18:34 --> Severity: Notice --> Undefined property: Struktur_organisasi::$Struktur_organisasi /home/u164602079/public_html/dinaspu/application/controllers/Struktur_organisasi.php 22
ERROR - 2018-12-28 03:18:34 --> Severity: error --> Exception: Call to a member function get_data() on null /home/u164602079/public_html/dinaspu/application/controllers/Struktur_organisasi.php 22
ERROR - 2018-12-28 03:18:35 --> Severity: Notice --> Undefined property: Struktur_organisasi::$Struktur_organisasi /home/u164602079/public_html/dinaspu/application/controllers/Struktur_organisasi.php 22
ERROR - 2018-12-28 03:18:35 --> Severity: error --> Exception: Call to a member function get_data() on null /home/u164602079/public_html/dinaspu/application/controllers/Struktur_organisasi.php 22
ERROR - 2018-12-28 03:18:37 --> Severity: Notice --> Undefined property: Struktur_organisasi::$Struktur_organisasi /home/u164602079/public_html/dinaspu/application/controllers/Struktur_organisasi.php 22
ERROR - 2018-12-28 03:18:37 --> Severity: error --> Exception: Call to a member function get_data() on null /home/u164602079/public_html/dinaspu/application/controllers/Struktur_organisasi.php 22
ERROR - 2018-12-28 03:18:51 --> Severity: error --> Exception: Class Struktur_organisasi already exists and doesn't extend CI_Model /home/u164602079/public_html/dinaspu/system/core/Loader.php 353
ERROR - 2018-12-28 03:18:51 --> Severity: error --> Exception: Class Struktur_organisasi already exists and doesn't extend CI_Model /home/u164602079/public_html/dinaspu/system/core/Loader.php 353
ERROR - 2018-12-28 03:19:59 --> Query error: Unknown column 'so.jabatan_id' in 'on clause' - Invalid query: SELECT *
FROM `struktur_organisasi`
JOIN `jabatan` ON `so`.`jabatan_id` = `jabatan`.`jabatan_id`
ERROR - 2018-12-28 03:19:59 --> Query error: Unknown column 'so.jabatan_id' in 'on clause' - Invalid query: SELECT *
FROM `struktur_organisasi`
JOIN `jabatan` ON `so`.`jabatan_id` = `jabatan`.`jabatan_id`
ERROR - 2018-12-28 03:20:54 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:20:54 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:20:54 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:20:55 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:20:55 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:22:14 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:22:14 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:22:14 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:22:14 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:22:15 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:23:12 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:23:12 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:23:12 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:23:12 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:23:12 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:23:41 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:23:41 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:23:41 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:23:42 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:23:49 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:23:49 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:23:49 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:24:09 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:24:09 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:24:09 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:27:45 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:27:46 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:27:46 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:27:46 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:27:46 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:27:50 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:27:50 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:27:50 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:27:51 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:27:51 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:30:32 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:30:32 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:30:32 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:31:09 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:31:09 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:31:09 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:31:13 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:31:13 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:31:14 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:31:14 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:33:40 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:33:40 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:33:40 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:33:40 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:33:41 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:33:41 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:33:41 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:33:41 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:33:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:33:46 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:33:46 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 03:33:46 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 04:12:02 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 04:12:02 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 04:12:02 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 04:12:03 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 04:12:04 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 04:12:04 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 04:12:04 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 05:38:41 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 05:38:41 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 05:38:41 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 05:38:41 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 05:38:41 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 05:38:44 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 05:38:44 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 05:38:44 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 05:38:45 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 05:38:45 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 05:38:48 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 05:38:48 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 05:38:49 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 05:38:51 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 05:38:51 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 05:38:51 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 05:39:12 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 05:39:12 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-28 05:39:12 --> 404 Page Not Found: An-theme/ando
