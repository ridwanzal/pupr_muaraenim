<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-11-29 08:00:27 --> Severity: error --> Exception: syntax error, unexpected '$dataTag' (T_VARIABLE) /opt/lampp/htdocs/dinaspu/application/controllers/AN_admin.php 499
ERROR - 2018-11-29 08:01:03 --> Severity: error --> Exception: syntax error, unexpected '$dataTag' (T_VARIABLE) /opt/lampp/htdocs/dinaspu/application/controllers/AN_admin.php 499
ERROR - 2018-11-29 08:01:06 --> Severity: error --> Exception: syntax error, unexpected '$dataTag' (T_VARIABLE) /opt/lampp/htdocs/dinaspu/application/controllers/AN_admin.php 499
ERROR - 2018-11-29 08:01:25 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ')' /opt/lampp/htdocs/dinaspu/application/controllers/AN_admin.php 502
ERROR - 2018-11-29 08:01:34 --> Severity: error --> Exception: syntax error, unexpected '=' /opt/lampp/htdocs/dinaspu/application/controllers/AN_admin.php 506
ERROR - 2018-11-29 08:01:52 --> 404 Page Not Found: Img/pu.png
