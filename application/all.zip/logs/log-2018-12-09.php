<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-12-09 02:24:59 --> 404 Page Not Found: Data_infrastruktur/index
ERROR - 2018-12-09 02:25:31 --> 404 Page Not Found: Data_infrastruktur/index
ERROR - 2018-12-09 02:27:13 --> 404 Page Not Found: Data_infrastruktur/index
ERROR - 2018-12-09 02:28:10 --> 404 Page Not Found: Data_infrastruktur/index
ERROR - 2018-12-09 02:28:13 --> 404 Page Not Found: Data_infrastruktur/index
ERROR - 2018-12-09 02:28:28 --> 404 Page Not Found: Data_infrastruktur/index
ERROR - 2018-12-09 02:35:53 --> Severity: error --> Exception: Call to undefined function path_adm() /opt/lampp/htdocs/dinaspu/application/views/ando/header.php 78
ERROR - 2018-12-09 02:36:39 --> Severity: error --> Exception: Call to undefined function path_adm() /opt/lampp/htdocs/dinaspu/application/views/ando/header.php 78
ERROR - 2018-12-09 02:48:38 --> Severity: error --> Exception: syntax error, unexpected 'rel' (T_STRING), expecting ',' or ';' /opt/lampp/htdocs/dinaspu/application/views/ando/header.php 78
ERROR - 2018-12-09 02:51:51 --> Severity: error --> Exception: syntax error, unexpected 'rel' (T_STRING), expecting ',' or ';' /opt/lampp/htdocs/dinaspu/application/views/ando/header.php 78
ERROR - 2018-12-09 02:52:13 --> Severity: error --> Exception: syntax error, unexpected 'rel' (T_STRING), expecting ',' or ';' /opt/lampp/htdocs/dinaspu/application/views/ando/header.php 78
ERROR - 2018-12-09 03:20:51 --> 404 Page Not Found: Img/pu.png
ERROR - 2018-12-09 03:20:52 --> 404 Page Not Found: Img/pu.png
ERROR - 2018-12-09 03:31:03 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-09 03:31:03 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-09 03:31:03 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-09 03:31:03 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-09 03:31:15 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-09 03:31:15 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-09 03:31:15 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-09 03:31:15 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-09 03:59:08 --> Severity: error --> Exception: Unable to locate the model you have specified: Produk_hukum /opt/lampp/htdocs/dinaspu/system/core/Loader.php 348
ERROR - 2018-12-09 04:11:11 --> Severity: error --> Exception: Unable to locate the model you have specified: Produk_hukum /opt/lampp/htdocs/dinaspu/system/core/Loader.php 348
ERROR - 2018-12-09 04:17:14 --> Severity: Notice --> Undefined property: AN_admin::$infrastruktur /opt/lampp/htdocs/dinaspu/application/controllers/AN_admin.php 560
ERROR - 2018-12-09 04:17:14 --> Severity: error --> Exception: Call to a member function get_infrastruktur() on null /opt/lampp/htdocs/dinaspu/application/controllers/AN_admin.php 560
ERROR - 2018-12-09 04:19:42 --> Query error: Table 'db_dinaspu.produk_hukum' doesn't exist - Invalid query: SELECT *
FROM `produk_hukum`
ERROR - 2018-12-09 04:39:34 --> Severity: error --> Exception: syntax error, unexpected 'produk_hukum' (T_STRING), expecting '(' /opt/lampp/htdocs/dinaspu/application/controllers/AN_admin.php 542
ERROR - 2018-12-09 05:05:10 --> Query error: Unknown column 'date' in 'field list' - Invalid query: INSERT INTO `produk_hukum` (`id_produk_hukum`, `nama_file`, `tahun`, `keterangan`, `date`) VALUES (5442, NULL, '1958', 'keterangan', '2018-12-09')
ERROR - 2018-12-09 05:05:29 --> Query error: Column 'nama_file' cannot be null - Invalid query: INSERT INTO `produk_hukum` (`id_produk_hukum`, `nama_file`, `tahun`, `keterangan`, `date`) VALUES (48294, NULL, '1958', 'keterangan', '2018-12-09')
ERROR - 2018-12-09 05:14:20 --> Severity: error --> Exception: Class Produk_hukum already exists and doesn't extend CI_Model /opt/lampp/htdocs/dinaspu/system/core/Loader.php 353
ERROR - 2018-12-09 05:14:23 --> Severity: error --> Exception: Class Produk_hukum already exists and doesn't extend CI_Model /opt/lampp/htdocs/dinaspu/system/core/Loader.php 353
ERROR - 2018-12-09 05:15:28 --> Severity: error --> Exception: Class Produk_hukum already exists and doesn't extend CI_Model /opt/lampp/htdocs/dinaspu/system/core/Loader.php 353
ERROR - 2018-12-09 07:18:23 --> Severity: error --> Exception: syntax error, unexpected 's' (T_STRING), expecting ',' or ')' /opt/lampp/htdocs/dinaspu/application/controllers/Produk_hukum.php 17
ERROR - 2018-12-09 07:18:35 --> Severity: error --> Exception: Class Produk_hukum already exists and doesn't extend CI_Model /opt/lampp/htdocs/dinaspu/system/core/Loader.php 353
ERROR - 2018-12-09 07:22:36 --> Severity: error --> Exception: Class Produk_hukum already exists and doesn't extend CI_Model /opt/lampp/htdocs/dinaspu/system/core/Loader.php 353
ERROR - 2018-12-09 07:26:52 --> Severity: error --> Exception: Class Produk_hukum already exists and doesn't extend CI_Model /opt/lampp/htdocs/dinaspu/system/core/Loader.php 353
ERROR - 2018-12-09 07:30:09 --> 404 Page Not Found: Img/pu.png
ERROR - 2018-12-09 07:30:10 --> 404 Page Not Found: Img/pu.png
ERROR - 2018-12-09 07:30:25 --> 404 Page Not Found: Img/pu.png
ERROR - 2018-12-09 07:30:40 --> Severity: error --> Exception: Unable to locate the model you have specified: Produk_hukum /opt/lampp/htdocs/dinaspu/system/core/Loader.php 348
ERROR - 2018-12-09 08:13:42 --> Severity: Warning --> Use of undefined constant k - assumed 'k' (this will throw an Error in a future version of PHP) /opt/lampp/htdocs/dinaspu/application/views/admin/data_infastruktur.php 100
ERROR - 2018-12-09 08:13:42 --> Severity: Warning --> Use of undefined constant k - assumed 'k' (this will throw an Error in a future version of PHP) /opt/lampp/htdocs/dinaspu/application/views/admin/data_infastruktur.php 100
ERROR - 2018-12-09 08:24:49 --> 404 Page Not Found: Berita/index
ERROR - 2018-12-09 08:44:06 --> Severity: error --> Exception: syntax error, unexpected ';' /opt/lampp/htdocs/dinaspu/application/controllers/AN_admin.php 625
ERROR - 2018-12-09 08:44:45 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /opt/lampp/htdocs/dinaspu/application/controllers/AN_admin.php 621
ERROR - 2018-12-09 08:49:26 --> Severity: error --> Exception: syntax error, unexpected '$expBidang' (T_VARIABLE) /opt/lampp/htdocs/dinaspu/application/controllers/AN_admin.php 628
ERROR - 2018-12-09 08:50:14 --> Severity: error --> Exception: syntax error, unexpected '$expBidang' (T_VARIABLE) /opt/lampp/htdocs/dinaspu/application/controllers/AN_admin.php 628
ERROR - 2018-12-09 09:03:13 --> Severity: error --> Exception: syntax error, unexpected 'else' (T_ELSE), expecting function (T_FUNCTION) or const (T_CONST) /opt/lampp/htdocs/dinaspu/application/controllers/AN_admin.php 638
ERROR - 2018-12-09 09:03:27 --> Severity: Warning --> array_pop() expects parameter 1 to be array, string given /opt/lampp/htdocs/dinaspu/application/controllers/AN_admin.php 635
ERROR - 2018-12-09 09:22:46 --> Severity: Notice --> Undefined property: stdClass::$bidang_tujuan /opt/lampp/htdocs/dinaspu/application/models/admin/Bidang.php 21
ERROR - 2018-12-09 09:22:54 --> Severity: Notice --> Undefined property: stdClass::$bidang_tujuan /opt/lampp/htdocs/dinaspu/application/models/admin/Bidang.php 21
ERROR - 2018-12-09 09:48:50 --> Severity: Notice --> Undefined property: stdClass::$bidang_tujuan /opt/lampp/htdocs/dinaspu/application/models/admin/Bidang.php 25
ERROR - 2018-12-09 09:48:55 --> Severity: Notice --> Undefined variable: id /opt/lampp/htdocs/dinaspu/application/controllers/AN_admin.php 712
ERROR - 2018-12-09 09:48:55 --> Query error: Unknown column 'id_bidang' in 'where clause' - Invalid query: SELECT *
FROM `bidang`
WHERE `id_bidang` = '1307'
ERROR - 2018-12-09 09:49:06 --> Severity: Notice --> Undefined variable: id /opt/lampp/htdocs/dinaspu/application/controllers/AN_admin.php 724
ERROR - 2018-12-09 09:49:06 --> Query error: Unknown column 'id_bidang' in 'where clause' - Invalid query: SELECT *
FROM `bidang`
WHERE `id_bidang` = '1307'
ERROR - 2018-12-09 09:49:19 --> Query error: Unknown column 'id_bidang' in 'where clause' - Invalid query: SELECT *
FROM `bidang`
WHERE `id_bidang` = '1307'
ERROR - 2018-12-09 09:50:04 --> Query error: Unknown column 'id_bidang' in 'where clause' - Invalid query: SELECT *
FROM `bidang`
WHERE `id_bidang` = '1307'
ERROR - 2018-12-09 09:50:20 --> Severity: error --> Exception: Cannot use object of type stdClass as array /opt/lampp/htdocs/dinaspu/application/views/admin/edit_bidang.php 27
ERROR - 2018-12-09 09:50:43 --> Severity: error --> Exception: Cannot use object of type stdClass as array /opt/lampp/htdocs/dinaspu/application/views/admin/edit_bidang.php 27
ERROR - 2018-12-09 09:51:34 --> Severity: error --> Exception: Cannot use object of type stdClass as array /opt/lampp/htdocs/dinaspu/application/views/admin/edit_bidang.php 27
ERROR - 2018-12-09 09:51:42 --> Severity: error --> Exception: Cannot use object of type stdClass as array /opt/lampp/htdocs/dinaspu/application/views/admin/edit_bidang.php 27
ERROR - 2018-12-09 09:52:34 --> Severity: error --> Exception: Cannot use object of type stdClass as array /opt/lampp/htdocs/dinaspu/application/views/admin/edit_bidang.php 58
ERROR - 2018-12-09 10:06:45 --> 404 Page Not Found: AN_admin/all_bdia
ERROR - 2018-12-09 10:21:59 --> Severity: error --> Exception: syntax error, unexpected '?>', expecting function (T_FUNCTION) or const (T_CONST) /opt/lampp/htdocs/dinaspu/application/controllers/AN_admin.php 1601
ERROR - 2018-12-09 10:24:53 --> Severity: error --> Exception: syntax error, unexpected '?>', expecting function (T_FUNCTION) or const (T_CONST) /opt/lampp/htdocs/dinaspu/application/controllers/AN_admin.php 1602
ERROR - 2018-12-09 10:27:48 --> Severity: Notice --> Undefined variable: get_infrastruktur /opt/lampp/htdocs/dinaspu/application/views/admin/data_infastruktur.php 90
ERROR - 2018-12-09 10:27:48 --> Severity: Warning --> Invalid argument supplied for foreach() /opt/lampp/htdocs/dinaspu/application/views/admin/data_infastruktur.php 90
ERROR - 2018-12-09 10:28:34 --> Severity: error --> Exception: Call to undefined method Infrastruktur::upd_data_infrastruktur() /opt/lampp/htdocs/dinaspu/application/controllers/AN_admin.php 529
ERROR - 2018-12-09 10:40:33 --> Severity: error --> Exception: syntax error, unexpected '?>', expecting function (T_FUNCTION) or const (T_CONST) /opt/lampp/htdocs/dinaspu/application/controllers/AN_admin.php 1632
ERROR - 2018-12-09 10:44:13 --> Severity: error --> Exception: syntax error, unexpected ')' /opt/lampp/htdocs/dinaspu/application/controllers/AN_admin.php 615
ERROR - 2018-12-09 10:44:28 --> Severity: Notice --> Undefined variable: get_produk_hukum /opt/lampp/htdocs/dinaspu/application/views/admin/produk_hukum.php 92
ERROR - 2018-12-09 10:44:28 --> Severity: Warning --> Invalid argument supplied for foreach() /opt/lampp/htdocs/dinaspu/application/views/admin/produk_hukum.php 92
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'nama_file' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 30
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'tahun' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 41
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'keterangan' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 50
ERROR - 2018-12-09 10:45:35 --> Severity: Notice --> Trying to get property 'id_produk_hukum' of non-object /opt/lampp/htdocs/dinaspu/application/views/admin/edit_produk_hukum.php 53
ERROR - 2018-12-09 11:03:39 --> Severity: Notice --> Undefined index: nama /opt/lampp/htdocs/dinaspu/application/controllers/AN_admin.php 665
ERROR - 2018-12-09 11:03:39 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /opt/lampp/htdocs/dinaspu/application/controllers/AN_admin.php 665
ERROR - 2018-12-09 11:03:39 --> The upload destination folder does not appear to be writable.
ERROR - 2018-12-09 11:07:48 --> The upload destination folder does not appear to be writable.
ERROR - 2018-12-09 11:09:19 --> The upload destination folder does not appear to be writable.
ERROR - 2018-12-09 11:10:28 --> Severity: Notice --> Array to string conversion /opt/lampp/htdocs/dinaspu/application/controllers/AN_admin.php 683
ERROR - 2018-12-09 11:21:15 --> Severity: error --> Exception: Call to undefined function base_url() /opt/lampp/htdocs/dinaspu/application/views/ando/produk_hukum.php 19
ERROR - 2018-12-09 11:30:06 --> Severity: error --> Exception: syntax error, unexpected '$config' (T_VARIABLE) /opt/lampp/htdocs/dinaspu/application/controllers/AN_admin.php 791
ERROR - 2018-12-09 11:36:09 --> Severity: Notice --> Trying to get property 'bidang_foto' of non-object /opt/lampp/htdocs/dinaspu/application/views/ando/bidang.php 20
ERROR - 2018-12-09 11:36:58 --> Severity: Notice --> Undefined index: bidang_foto /opt/lampp/htdocs/dinaspu/application/views/ando/bidang.php 20
ERROR - 2018-12-09 11:38:39 --> 404 Page Not Found: Bidang/uploads
ERROR - 2018-12-09 13:05:27 --> 404 Page Not Found: Kategori/berita
ERROR - 2018-12-09 14:18:39 --> 404 Page Not Found: Bidang/uploads
ERROR - 2018-12-09 14:28:39 --> 404 Page Not Found: Bidang/uploads
ERROR - 2018-12-09 14:33:39 --> 404 Page Not Found: Bidang/uploads
ERROR - 2018-12-09 15:08:33 --> Severity: Notice --> Undefined variable: result /opt/lampp/htdocs/dinaspu/application/controllers/AN_admin.php 831
ERROR - 2018-12-09 15:08:33 --> Query error: Column 'bidang_foto' cannot be null - Invalid query: INSERT INTO `bidang` (`bidang_id`, `kategori_id`, `bidang_judul`, `bidang_tugas`, `bidang_url`, `bidang_foto`, `bidang_fungsi`) VALUES (8445, '11', 'wgwg wgweg', '&lt;p&gt;wegwg&lt;/p&gt;', 'http://localhost/dinaspu/bidang/8445-wgwg', NULL, '&lt;p&gt;ewgweg&lt;/p&gt;')
