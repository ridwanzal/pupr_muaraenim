<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-12-26 03:24:28 --> 404 Page Not Found: Img/pu.png
ERROR - 2018-12-26 03:24:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2018-12-26 03:24:46 --> 404 Page Not Found: Img/pu.png
ERROR - 2018-12-26 03:25:10 --> 404 Page Not Found: Img/pu.png
ERROR - 2018-12-26 18:04:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2018-12-26 18:04:42 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-26 18:04:46 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-26 18:04:59 --> 404 Page Not Found: An-theme/ando
