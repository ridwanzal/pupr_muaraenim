<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-12-31 07:01:44 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-31 07:01:45 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-31 07:01:45 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-31 07:01:45 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-31 07:01:46 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-31 11:36:10 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'puprmuar_dpu'@'localhost' (using password: YES) /home/u164602079/public_html/dinaspu/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2018-12-31 11:36:10 --> Unable to connect to the database
ERROR - 2018-12-31 11:36:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2018-12-31 11:37:49 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'puprmuar_dpu'@'localhost' (using password: YES) /home/u164602079/public_html/dinaspu/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2018-12-31 11:37:49 --> Unable to connect to the database
ERROR - 2018-12-31 11:46:15 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'puprmuar_dpu'@'localhost' (using password: YES) /home/u164602079/public_html/dinaspu/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2018-12-31 11:46:15 --> Unable to connect to the database
ERROR - 2018-12-31 11:46:21 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'puprmuar_dpu'@'localhost' (using password: YES) /home/u164602079/public_html/dinaspu/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2018-12-31 11:46:21 --> Unable to connect to the database
ERROR - 2018-12-31 14:41:13 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'puprmuar_dpu'@'localhost' (using password: YES) /home/u164602079/public_html/dinaspu/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2018-12-31 14:41:13 --> Unable to connect to the database
ERROR - 2018-12-31 14:41:14 --> 404 Page Not Found: Faviconico/index
