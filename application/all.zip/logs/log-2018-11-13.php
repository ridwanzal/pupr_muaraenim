<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-11-13 04:29:20 --> 404 Page Not Found: Admin/index
ERROR - 2018-11-13 04:33:21 --> 404 Page Not Found: AN_admin/home
ERROR - 2018-11-13 05:09:52 --> Severity: Notice --> Trying to get property 'password_user' of non-object /opt/lampp/htdocs/dinaspu/application/controllers/AN_admin.php 1263
ERROR - 2018-11-13 05:09:54 --> Severity: Notice --> Trying to get property 'password_user' of non-object /opt/lampp/htdocs/dinaspu/application/controllers/AN_admin.php 1263
ERROR - 2018-11-13 07:10:38 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /opt/lampp/htdocs/dinaspu/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2018-11-13 07:10:38 --> Unable to connect to the database
ERROR - 2018-11-13 07:11:04 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /opt/lampp/htdocs/dinaspu/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2018-11-13 07:11:04 --> Unable to connect to the database
ERROR - 2018-11-13 07:19:13 --> Severity: Notice --> Trying to get property 'password_user' of non-object /opt/lampp/htdocs/dinaspu/application/controllers/AN_admin.php 1262
ERROR - 2018-11-13 07:25:51 --> 404 Page Not Found: AN_admin/home
ERROR - 2018-11-13 07:26:08 --> 404 Page Not Found: AN_admin/home
ERROR - 2018-11-13 07:28:29 --> Severity: Notice --> Undefined index: random_filemanager_key /opt/lampp/htdocs/dinaspu/application/views/admin/footer.php 5397
ERROR - 2018-11-13 07:28:29 --> Severity: Notice --> Undefined index: random_filemanager_key /opt/lampp/htdocs/dinaspu/application/views/admin/footer.php 5411
ERROR - 2018-11-13 07:28:29 --> Severity: Notice --> Undefined index: random_filemanager_key /opt/lampp/htdocs/dinaspu/application/views/admin/footer.php 5470
ERROR - 2018-11-13 07:28:36 --> Severity: Notice --> Undefined index: random_filemanager_key /opt/lampp/htdocs/dinaspu/application/views/admin/footer.php 5397
ERROR - 2018-11-13 07:28:36 --> Severity: Notice --> Undefined index: random_filemanager_key /opt/lampp/htdocs/dinaspu/application/views/admin/footer.php 5411
ERROR - 2018-11-13 07:28:36 --> Severity: Notice --> Undefined index: random_filemanager_key /opt/lampp/htdocs/dinaspu/application/views/admin/footer.php 5470
ERROR - 2018-11-13 07:42:23 --> Severity: Notice --> Undefined index: random_filemanager_key /opt/lampp/htdocs/dinaspu/application/views/admin/footer.php 5397
ERROR - 2018-11-13 07:42:23 --> Severity: Notice --> Undefined index: random_filemanager_key /opt/lampp/htdocs/dinaspu/application/views/admin/footer.php 5411
ERROR - 2018-11-13 07:42:23 --> Severity: Notice --> Undefined index: random_filemanager_key /opt/lampp/htdocs/dinaspu/application/views/admin/footer.php 5470
ERROR - 2018-11-13 07:42:45 --> Severity: Notice --> Undefined index: random_filemanager_key /opt/lampp/htdocs/dinaspu/application/views/admin/footer.php 5397
ERROR - 2018-11-13 07:42:45 --> Severity: Notice --> Undefined index: random_filemanager_key /opt/lampp/htdocs/dinaspu/application/views/admin/footer.php 5411
ERROR - 2018-11-13 07:42:45 --> Severity: Notice --> Undefined index: random_filemanager_key /opt/lampp/htdocs/dinaspu/application/views/admin/footer.php 5470
ERROR - 2018-11-13 07:44:55 --> Severity: Notice --> Undefined index: random_filemanager_key /opt/lampp/htdocs/dinaspu/application/views/admin/footer.php 5397
ERROR - 2018-11-13 07:44:55 --> Severity: Notice --> Undefined index: random_filemanager_key /opt/lampp/htdocs/dinaspu/application/views/admin/footer.php 5411
ERROR - 2018-11-13 07:44:55 --> Severity: Notice --> Undefined index: random_filemanager_key /opt/lampp/htdocs/dinaspu/application/views/admin/footer.php 5470
ERROR - 2018-11-13 07:45:22 --> Severity: Notice --> Undefined index: random_filemanager_key /opt/lampp/htdocs/dinaspu/application/views/admin/footer.php 5397
ERROR - 2018-11-13 07:45:22 --> Severity: Notice --> Undefined index: random_filemanager_key /opt/lampp/htdocs/dinaspu/application/views/admin/footer.php 5411
ERROR - 2018-11-13 07:45:22 --> Severity: Notice --> Undefined index: random_filemanager_key /opt/lampp/htdocs/dinaspu/application/views/admin/footer.php 5470
ERROR - 2018-11-13 07:45:38 --> Severity: Notice --> Undefined index: random_filemanager_key /opt/lampp/htdocs/dinaspu/application/views/admin/footer.php 5397
ERROR - 2018-11-13 07:45:38 --> Severity: Notice --> Undefined index: random_filemanager_key /opt/lampp/htdocs/dinaspu/application/views/admin/footer.php 5411
ERROR - 2018-11-13 07:45:38 --> Severity: Notice --> Undefined index: random_filemanager_key /opt/lampp/htdocs/dinaspu/application/views/admin/footer.php 5470
ERROR - 2018-11-13 07:48:46 --> Severity: Notice --> Undefined index: random_filemanager_key /opt/lampp/htdocs/dinaspu/application/views/admin/footer.php 5397
ERROR - 2018-11-13 07:48:46 --> Severity: Notice --> Undefined index: random_filemanager_key /opt/lampp/htdocs/dinaspu/application/views/admin/footer.php 5411
ERROR - 2018-11-13 07:48:46 --> Severity: Notice --> Undefined index: random_filemanager_key /opt/lampp/htdocs/dinaspu/application/views/admin/footer.php 5470
ERROR - 2018-11-13 07:48:50 --> Severity: Notice --> Undefined index: random_filemanager_key /opt/lampp/htdocs/dinaspu/application/views/admin/footer.php 5397
ERROR - 2018-11-13 07:48:50 --> Severity: Notice --> Undefined index: random_filemanager_key /opt/lampp/htdocs/dinaspu/application/views/admin/footer.php 5411
ERROR - 2018-11-13 07:48:50 --> Severity: Notice --> Undefined index: random_filemanager_key /opt/lampp/htdocs/dinaspu/application/views/admin/footer.php 5470
ERROR - 2018-11-13 07:48:56 --> Severity: Notice --> Undefined index: random_filemanager_key /opt/lampp/htdocs/dinaspu/application/views/admin/footer.php 5397
ERROR - 2018-11-13 07:48:56 --> Severity: Notice --> Undefined index: random_filemanager_key /opt/lampp/htdocs/dinaspu/application/views/admin/footer.php 5411
ERROR - 2018-11-13 07:48:56 --> Severity: Notice --> Undefined index: random_filemanager_key /opt/lampp/htdocs/dinaspu/application/views/admin/footer.php 5470
ERROR - 2018-11-13 07:51:51 --> Severity: Notice --> Undefined index: random_filemanager_key /opt/lampp/htdocs/dinaspu/application/views/admin/footer.php 5397
ERROR - 2018-11-13 07:51:51 --> Severity: Notice --> Undefined index: random_filemanager_key /opt/lampp/htdocs/dinaspu/application/views/admin/footer.php 5411
ERROR - 2018-11-13 07:51:51 --> Severity: Notice --> Undefined index: random_filemanager_key /opt/lampp/htdocs/dinaspu/application/views/admin/footer.php 5470
ERROR - 2018-11-13 07:52:10 --> Severity: Notice --> Undefined index: random_filemanager_key /opt/lampp/htdocs/dinaspu/application/views/admin/footer.php 5397
ERROR - 2018-11-13 07:52:10 --> Severity: Notice --> Undefined index: random_filemanager_key /opt/lampp/htdocs/dinaspu/application/views/admin/footer.php 5411
ERROR - 2018-11-13 07:52:10 --> Severity: Notice --> Undefined index: random_filemanager_key /opt/lampp/htdocs/dinaspu/application/views/admin/footer.php 5470
ERROR - 2018-11-13 07:59:17 --> Severity: Notice --> Undefined index: random_filemanager_key /opt/lampp/htdocs/dinaspu/application/views/admin/footer.php 5397
ERROR - 2018-11-13 07:59:17 --> Severity: Notice --> Undefined index: random_filemanager_key /opt/lampp/htdocs/dinaspu/application/views/admin/footer.php 5411
ERROR - 2018-11-13 07:59:17 --> Severity: Notice --> Undefined index: random_filemanager_key /opt/lampp/htdocs/dinaspu/application/views/admin/footer.php 5470
ERROR - 2018-11-13 07:59:48 --> Severity: Notice --> Undefined index: random_filemanager_key /opt/lampp/htdocs/dinaspu/application/views/admin/footer.php 5397
ERROR - 2018-11-13 07:59:48 --> Severity: Notice --> Undefined index: random_filemanager_key /opt/lampp/htdocs/dinaspu/application/views/admin/footer.php 5411
ERROR - 2018-11-13 07:59:48 --> Severity: Notice --> Undefined index: random_filemanager_key /opt/lampp/htdocs/dinaspu/application/views/admin/footer.php 5470
ERROR - 2018-11-13 08:00:37 --> Severity: Notice --> Undefined index: random_filemanager_key /opt/lampp/htdocs/dinaspu/application/views/admin/footer.php 5397
ERROR - 2018-11-13 08:00:37 --> Severity: Notice --> Undefined index: random_filemanager_key /opt/lampp/htdocs/dinaspu/application/views/admin/footer.php 5411
ERROR - 2018-11-13 08:00:37 --> Severity: Notice --> Undefined index: random_filemanager_key /opt/lampp/htdocs/dinaspu/application/views/admin/footer.php 5470
ERROR - 2018-11-13 08:00:46 --> 404 Page Not Found: 
ERROR - 2018-11-13 08:00:54 --> Severity: Notice --> Undefined index: random_filemanager_key /opt/lampp/htdocs/dinaspu/application/views/admin/footer.php 5397
ERROR - 2018-11-13 08:00:54 --> Severity: Notice --> Undefined index: random_filemanager_key /opt/lampp/htdocs/dinaspu/application/views/admin/footer.php 5411
ERROR - 2018-11-13 08:00:54 --> Severity: Notice --> Undefined index: random_filemanager_key /opt/lampp/htdocs/dinaspu/application/views/admin/footer.php 5470
ERROR - 2018-11-13 08:01:01 --> 404 Page Not Found: 
ERROR - 2018-11-13 08:02:47 --> Severity: Notice --> Undefined index: random_filemanager_key /opt/lampp/htdocs/dinaspu/application/views/admin/footer.php 5397
ERROR - 2018-11-13 08:02:47 --> Severity: Notice --> Undefined index: random_filemanager_key /opt/lampp/htdocs/dinaspu/application/views/admin/footer.php 5411
ERROR - 2018-11-13 08:02:47 --> Severity: Notice --> Undefined index: random_filemanager_key /opt/lampp/htdocs/dinaspu/application/views/admin/footer.php 5470
ERROR - 2018-11-13 08:18:56 --> 404 Page Not Found: 
ERROR - 2018-11-13 08:23:33 --> 404 Page Not Found: 
ERROR - 2018-11-13 08:28:19 --> 404 Page Not Found: Login/index
ERROR - 2018-11-13 08:28:30 --> Severity: error --> Exception: syntax error, unexpected 'AN_admin' (T_STRING) /opt/lampp/htdocs/dinaspu/application/controllers/AN_admin.php 4
ERROR - 2018-11-13 08:29:20 --> Severity: error --> Exception: syntax error, unexpected 'AN_admin' (T_STRING) /opt/lampp/htdocs/dinaspu/application/controllers/AN_admin.php 4
ERROR - 2018-11-13 08:29:26 --> Severity: error --> Exception: syntax error, unexpected 'AN_admin' (T_STRING) /opt/lampp/htdocs/dinaspu/application/controllers/AN_admin.php 4
ERROR - 2018-11-13 08:30:40 --> Severity: error --> Exception: syntax error, unexpected 'AN_admin' (T_STRING) /opt/lampp/htdocs/dinaspu/application/controllers/AN_admin.php 4
ERROR - 2018-11-13 08:31:37 --> Severity: error --> Exception: syntax error, unexpected 'AN_admin' (T_STRING) /opt/lampp/htdocs/dinaspu/application/controllers/AN_admin.php 4
ERROR - 2018-11-13 08:51:56 --> 404 Page Not Found: Profil/index
