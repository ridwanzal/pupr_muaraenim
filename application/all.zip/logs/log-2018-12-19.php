<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-12-19 01:53:36 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 01:53:36 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 01:53:36 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 01:53:36 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 01:53:36 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 01:53:36 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 01:53:38 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 01:53:38 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 01:53:58 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 01:53:58 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 01:53:58 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 01:53:58 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 01:53:58 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 01:53:59 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 01:53:59 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 01:53:59 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 01:53:59 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 01:54:32 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 01:54:32 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 01:54:32 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 01:54:33 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 01:54:33 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 01:54:40 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 01:54:40 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 01:54:40 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 01:54:40 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 01:54:40 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 01:55:35 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 01:55:35 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 01:55:35 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 01:55:35 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 01:55:35 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 04:46:08 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 04:46:08 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 04:46:08 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 04:46:09 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 04:46:09 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 04:46:11 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 04:46:12 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 04:46:12 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 04:46:12 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 04:46:38 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 04:46:38 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 04:46:38 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 04:46:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 04:46:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 04:46:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 04:46:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 04:46:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 04:47:35 --> 404 Page Not Found: Img/pu.png
ERROR - 2018-12-19 04:47:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2018-12-19 04:49:25 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 04:49:26 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 04:49:26 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 04:49:26 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 04:49:30 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 04:49:30 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 04:49:30 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 04:49:31 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 04:49:31 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 04:49:43 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 04:49:43 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 04:49:43 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 04:49:43 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 04:49:43 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 04:54:21 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 04:54:21 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 04:54:21 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 04:54:25 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 04:54:25 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 04:54:25 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 04:55:04 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 04:55:04 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 04:55:04 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 04:55:04 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 04:55:04 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 04:55:43 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 04:55:43 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 04:55:43 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 04:55:43 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 04:55:45 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 04:55:45 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 04:55:45 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 04:55:45 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 04:55:45 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 04:55:48 --> Severity: Notice --> Use of undefined constant nama_pelaksana - assumed 'nama_pelaksana' /home/u164602079/public_html/dinaspu/application/controllers/AN_admin.php 553
ERROR - 2018-12-19 04:55:49 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 04:55:49 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 04:55:49 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 04:55:49 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 04:56:43 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 04:56:43 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 04:56:43 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 04:56:43 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 04:56:43 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 04:56:44 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 04:56:44 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 04:56:44 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 04:56:44 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 04:56:48 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 04:56:48 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 04:56:48 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 04:56:48 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 04:56:49 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 04:56:49 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 04:56:49 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 04:56:51 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 04:56:51 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 04:56:51 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 04:56:51 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 04:56:51 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 04:56:53 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 04:56:53 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 04:56:53 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 04:56:53 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 04:56:53 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 04:56:54 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 04:56:54 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 04:56:54 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 04:56:56 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 04:57:07 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 04:57:07 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 04:57:07 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 04:57:11 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 04:57:12 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 04:57:12 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 04:57:12 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 04:57:12 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 04:57:17 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 04:57:17 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 04:57:17 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 04:57:17 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 04:57:17 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 04:57:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 04:57:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 04:57:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 04:57:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 04:57:24 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 04:57:25 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 04:57:25 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 04:57:25 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 04:57:26 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 04:57:37 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 04:57:37 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 04:57:37 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 04:57:40 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 04:57:40 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 04:57:40 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 04:59:09 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 04:59:09 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 04:59:09 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 05:01:40 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 05:01:40 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 05:01:40 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 05:02:56 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 05:02:56 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 05:02:56 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 05:03:00 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 05:03:00 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 05:03:00 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 05:03:00 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 05:03:07 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 05:03:07 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 05:03:07 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 05:03:10 --> Query error: Unknown column 'date' in 'field list' - Invalid query: UPDATE `infrastruktur` SET `nama_kegiatan` = 'Kegiatan Pembangunan Jembatan di Kabupaten Merangin', `nama_pelaksana` = 'nama_pelaksana', `anggaran` = '57830355000', `nilai_kontrak` = '52904250', `progres` = '0', `ppk` = 'Edy Damhuri, MT', `date` = '2017'
WHERE `id_infrastruktur` = '94329'
ERROR - 2018-12-19 05:05:04 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 05:05:04 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 05:05:05 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 05:05:07 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 05:05:07 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 05:05:07 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 05:05:07 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 05:05:07 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 05:05:10 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 05:05:10 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 05:05:10 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 05:05:11 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 05:05:29 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 05:05:29 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 05:05:29 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 05:05:29 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 05:36:54 --> Query error: Unknown column 'year' in 'field list' - Invalid query: SELECT `year`
FROM `infrastruktur`
ERROR - 2018-12-19 05:37:18 --> Query error: Unknown column 'year' in 'field list' - Invalid query: SELECT `year`
FROM `infrastruktur`
ERROR - 2018-12-19 05:37:30 --> Severity: error --> Exception: Cannot use object of type stdClass as array /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 27
ERROR - 2018-12-19 05:37:39 --> Severity: Notice --> Undefined index: pesan /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 36
ERROR - 2018-12-19 05:37:39 --> Severity: Notice --> Undefined index: id /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 40
ERROR - 2018-12-19 05:37:39 --> Severity: Notice --> Undefined index: pesan /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 36
ERROR - 2018-12-19 05:37:39 --> Severity: Notice --> Undefined index: id /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 40
ERROR - 2018-12-19 05:37:39 --> Severity: Notice --> Undefined index: pesan /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 36
ERROR - 2018-12-19 05:37:39 --> Severity: Notice --> Undefined index: id /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 40
ERROR - 2018-12-19 05:37:39 --> Severity: Notice --> Undefined index: pesan /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 36
ERROR - 2018-12-19 05:37:39 --> Severity: Notice --> Undefined index: id /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 40
ERROR - 2018-12-19 05:37:39 --> Severity: Notice --> Undefined index: pesan /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 36
ERROR - 2018-12-19 05:37:39 --> Severity: Notice --> Undefined index: id /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 40
ERROR - 2018-12-19 05:37:39 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 05:37:39 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 05:37:39 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 05:37:40 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 05:37:40 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 05:38:16 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 05:38:16 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 05:38:16 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 05:38:16 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 05:38:16 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 05:38:18 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 05:38:18 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 05:38:18 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 05:38:18 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 05:39:02 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::result_array() /home/u164602079/public_html/dinaspu/application/models/admin/Infrastruktur.php 22
ERROR - 2018-12-19 05:40:01 --> Query error: Unknown column 'tahun' in 'group statement' - Invalid query: SELECT *
FROM `menu_child`
WHERE `menu_id` = 1
AND `menu_child_parent` = 0
AND `aktif` = 'Y'
GROUP BY `tahun`
ORDER BY `posisi` ASC
ERROR - 2018-12-19 05:40:01 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 05:40:20 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 05:40:20 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 05:40:20 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 05:40:20 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 05:40:41 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 05:40:41 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 05:40:41 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 05:40:41 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 05:43:23 --> Severity: Notice --> Undefined property: mysqli::$nama_kegiatan /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 57
ERROR - 2018-12-19 05:43:23 --> Severity: Notice --> Undefined property: mysqli::$anggaran /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 58
ERROR - 2018-12-19 05:43:23 --> Severity: Notice --> Undefined property: mysqli::$nilai_kontrak /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 59
ERROR - 2018-12-19 05:43:23 --> Severity: Notice --> Undefined property: mysqli::$progres /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 60
ERROR - 2018-12-19 05:43:23 --> Severity: Notice --> Undefined property: mysqli::$ppk /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 61
ERROR - 2018-12-19 05:43:23 --> Severity: Notice --> Undefined property: mysqli::$nama_kegiatan /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 62
ERROR - 2018-12-19 05:43:23 --> Severity: Notice --> Undefined property: mysqli_result::$nama_kegiatan /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 57
ERROR - 2018-12-19 05:43:23 --> Severity: Notice --> Undefined property: mysqli_result::$anggaran /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 58
ERROR - 2018-12-19 05:43:23 --> Severity: Notice --> Undefined property: mysqli_result::$nilai_kontrak /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 59
ERROR - 2018-12-19 05:43:23 --> Severity: Notice --> Undefined property: mysqli_result::$progres /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 60
ERROR - 2018-12-19 05:43:23 --> Severity: Notice --> Undefined property: mysqli_result::$ppk /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 61
ERROR - 2018-12-19 05:43:23 --> Severity: Notice --> Undefined property: mysqli_result::$nama_kegiatan /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 62
ERROR - 2018-12-19 05:43:23 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 57
ERROR - 2018-12-19 05:43:23 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 58
ERROR - 2018-12-19 05:43:23 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 59
ERROR - 2018-12-19 05:43:23 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 60
ERROR - 2018-12-19 05:43:23 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 61
ERROR - 2018-12-19 05:43:23 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 62
ERROR - 2018-12-19 05:43:23 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 57
ERROR - 2018-12-19 05:43:23 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 58
ERROR - 2018-12-19 05:43:23 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 59
ERROR - 2018-12-19 05:43:23 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 60
ERROR - 2018-12-19 05:43:23 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 61
ERROR - 2018-12-19 05:43:23 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 62
ERROR - 2018-12-19 05:43:23 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 57
ERROR - 2018-12-19 05:43:23 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 58
ERROR - 2018-12-19 05:43:23 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 59
ERROR - 2018-12-19 05:43:23 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 60
ERROR - 2018-12-19 05:43:23 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 61
ERROR - 2018-12-19 05:43:23 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 62
ERROR - 2018-12-19 05:43:23 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 57
ERROR - 2018-12-19 05:43:23 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 58
ERROR - 2018-12-19 05:43:23 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 59
ERROR - 2018-12-19 05:43:23 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 60
ERROR - 2018-12-19 05:43:23 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 61
ERROR - 2018-12-19 05:43:23 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 62
ERROR - 2018-12-19 05:43:23 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 57
ERROR - 2018-12-19 05:43:23 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 58
ERROR - 2018-12-19 05:43:23 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 59
ERROR - 2018-12-19 05:43:23 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 60
ERROR - 2018-12-19 05:43:23 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 61
ERROR - 2018-12-19 05:43:23 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 62
ERROR - 2018-12-19 05:43:23 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 57
ERROR - 2018-12-19 05:43:23 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 58
ERROR - 2018-12-19 05:43:23 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 59
ERROR - 2018-12-19 05:43:23 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 60
ERROR - 2018-12-19 05:43:23 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 61
ERROR - 2018-12-19 05:43:23 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 62
ERROR - 2018-12-19 05:43:23 --> Severity: Notice --> Undefined property: mysqli::$nama_kegiatan /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 57
ERROR - 2018-12-19 05:43:23 --> Severity: Notice --> Undefined property: mysqli::$anggaran /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 58
ERROR - 2018-12-19 05:43:23 --> Severity: Notice --> Undefined property: mysqli::$nilai_kontrak /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 59
ERROR - 2018-12-19 05:43:23 --> Severity: Notice --> Undefined property: mysqli::$progres /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 60
ERROR - 2018-12-19 05:43:23 --> Severity: Notice --> Undefined property: mysqli::$ppk /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 61
ERROR - 2018-12-19 05:43:23 --> Severity: Notice --> Undefined property: mysqli::$nama_kegiatan /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 62
ERROR - 2018-12-19 05:43:23 --> Severity: Notice --> Undefined property: mysqli_result::$nama_kegiatan /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 57
ERROR - 2018-12-19 05:43:23 --> Severity: Notice --> Undefined property: mysqli_result::$anggaran /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 58
ERROR - 2018-12-19 05:43:23 --> Severity: Notice --> Undefined property: mysqli_result::$nilai_kontrak /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 59
ERROR - 2018-12-19 05:43:23 --> Severity: Notice --> Undefined property: mysqli_result::$progres /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 60
ERROR - 2018-12-19 05:43:23 --> Severity: Notice --> Undefined property: mysqli_result::$ppk /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 61
ERROR - 2018-12-19 05:43:23 --> Severity: Notice --> Undefined property: mysqli_result::$nama_kegiatan /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 62
ERROR - 2018-12-19 05:43:23 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 57
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 58
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 59
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 60
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 61
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 62
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 57
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 58
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 59
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 60
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 61
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 62
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 57
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 58
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 59
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 60
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 61
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 62
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 57
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 58
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 59
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 60
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 61
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 62
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 57
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 58
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 59
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 60
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 61
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 62
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 57
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 58
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 59
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 60
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 61
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 62
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Undefined property: mysqli::$nama_kegiatan /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 57
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Undefined property: mysqli::$anggaran /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 58
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Undefined property: mysqli::$nilai_kontrak /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 59
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Undefined property: mysqli::$progres /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 60
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Undefined property: mysqli::$ppk /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 61
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Undefined property: mysqli::$nama_kegiatan /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 62
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Undefined property: mysqli_result::$nama_kegiatan /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 57
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Undefined property: mysqli_result::$anggaran /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 58
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Undefined property: mysqli_result::$nilai_kontrak /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 59
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Undefined property: mysqli_result::$progres /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 60
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Undefined property: mysqli_result::$ppk /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 61
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Undefined property: mysqli_result::$nama_kegiatan /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 62
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 57
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 58
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 59
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 60
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 61
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 62
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 57
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 58
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 59
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 60
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 61
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 62
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 57
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 58
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 59
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 60
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 61
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 62
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 57
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 58
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 59
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 60
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 61
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 62
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 57
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 58
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 59
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 60
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 61
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 62
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 57
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 58
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 59
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 60
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 61
ERROR - 2018-12-19 05:43:24 --> Severity: Notice --> Trying to get property of non-object /home/u164602079/public_html/dinaspu/application/views/ando/data_infrastruktur.php 62
ERROR - 2018-12-19 05:43:24 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 05:43:24 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 05:43:24 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 05:43:42 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 05:43:42 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 05:43:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 05:43:58 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 05:43:58 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 05:43:58 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 05:44:30 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 05:44:30 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 05:44:30 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 05:44:31 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 05:44:31 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 05:47:28 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 05:47:28 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 05:47:28 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 05:47:28 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 05:52:44 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 05:52:45 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 05:52:45 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 05:52:45 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 05:52:45 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 05:52:58 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 05:52:58 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 05:52:58 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 05:52:59 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 05:52:59 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 05:57:51 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 05:57:51 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 05:57:51 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 05:57:51 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 05:57:57 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 05:57:57 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 05:57:57 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 05:57:57 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 05:57:57 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 05:58:22 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 05:58:22 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 05:58:22 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 05:58:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 05:58:57 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 05:58:57 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 05:58:57 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 05:58:58 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 05:58:58 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 05:59:06 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 05:59:06 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 05:59:06 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 05:59:08 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 05:59:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 05:59:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 05:59:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 05:59:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:01:26 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:01:26 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:01:26 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:01:26 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:01:26 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:01:58 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:01:58 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:01:58 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:06:24 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:06:24 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:06:24 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:08:14 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:08:14 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:08:14 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:08:14 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:08:14 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:08:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:08:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:08:53 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:08:55 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:08:55 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:08:56 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:09:01 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:09:01 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:09:01 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:09:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:09:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:09:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:10:00 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:10:01 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:10:01 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:10:02 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:10:02 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:10:02 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:10:02 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:10:02 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:10:13 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:10:13 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:10:13 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:10:13 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:10:13 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:10:29 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:10:29 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:10:32 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:10:36 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:11:18 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:11:18 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:11:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:11:34 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:11:34 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:11:34 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:11:34 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:11:35 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:11:58 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:11:58 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:11:58 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:11:58 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:11:58 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:12:09 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:12:09 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:12:10 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:12:10 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:12:10 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:12:30 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:12:30 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:12:30 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:13:17 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:13:17 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:13:17 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:13:18 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:13:18 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:13:18 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:13:18 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:13:18 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:14:45 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:14:45 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:14:45 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:14:46 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:14:58 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:14:58 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:14:58 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:15:22 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:15:22 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:15:22 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:15:22 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:16:04 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:16:04 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:16:04 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:16:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:16:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:16:11 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:16:11 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:16:11 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:16:11 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:16:11 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:16:14 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:16:14 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:16:14 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:16:15 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:16:15 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:17:18 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:17:18 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:17:18 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:17:18 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:17:18 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:17:21 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:17:21 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:17:21 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:17:22 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:17:22 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:17:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:17:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:17:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:17:24 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:17:24 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:17:24 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:17:24 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:17:24 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:18:14 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:18:14 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:18:14 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:18:14 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:18:14 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:22:57 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:22:57 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:22:57 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:22:57 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:23:42 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 06:23:42 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 06:23:43 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 06:23:56 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:23:57 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 06:23:58 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 06:23:59 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:23:59 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:24:04 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:24:55 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 06:24:55 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 06:24:55 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 06:34:46 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 06:34:46 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 06:34:46 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 06:34:52 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:34:52 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:34:52 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:34:52 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:34:52 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:35:38 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 06:39:20 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 06:39:20 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 06:39:20 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 06:39:22 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:39:22 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:39:22 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:39:22 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:39:22 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:39:38 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:39:38 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:39:41 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:39:41 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:39:42 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:45:20 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:45:20 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:45:20 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:45:20 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:45:31 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:45:31 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:45:31 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:45:31 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:45:43 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:45:44 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:45:44 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:45:44 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:45:45 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:48:59 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 06:48:59 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 06:48:59 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 06:48:59 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 06:49:00 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:49:01 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:49:01 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:49:01 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:51:08 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 06:51:08 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 06:51:08 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 06:51:09 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 06:51:09 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 06:51:10 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:51:10 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:51:10 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:51:10 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:51:10 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:51:25 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 06:51:25 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 06:51:25 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 06:51:25 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 06:51:25 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 06:51:25 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:51:25 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:51:25 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:51:26 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:51:26 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:51:29 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:51:29 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:51:29 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:51:30 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:51:30 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:51:30 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:51:30 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:51:30 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:51:45 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:51:45 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:51:45 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:51:45 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:51:45 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:51:47 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:51:47 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:51:47 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:51:47 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:52:12 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 06:52:12 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 06:52:12 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 06:52:14 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:52:14 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:52:14 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:52:14 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:52:14 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:52:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:52:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:52:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:52:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:52:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:52:24 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:52:24 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:52:24 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:52:24 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:52:24 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:52:29 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 06:52:29 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 06:52:29 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 06:52:30 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 06:52:30 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 06:52:32 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:52:32 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:52:32 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:52:32 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:52:33 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:52:45 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:52:45 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:52:45 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:52:50 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:52:50 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:52:51 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:52:52 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:52:55 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 06:52:55 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 06:52:55 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 06:52:55 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 06:52:55 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 06:52:57 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:52:57 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:52:57 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:52:57 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:52:57 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:53:02 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 06:53:03 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 06:53:03 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 06:53:04 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:53:04 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:53:04 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:53:05 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:53:08 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 06:53:08 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 06:53:08 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 06:53:08 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 06:53:08 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 06:53:10 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:53:10 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:53:10 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:53:10 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:53:10 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:53:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:53:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:53:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:53:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:53:23 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:54:05 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 06:54:05 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 06:54:05 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-19 06:54:07 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:54:07 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:54:07 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:54:07 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:54:07 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:54:12 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:54:12 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:54:12 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:54:12 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 06:54:12 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 13:12:47 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 13:12:48 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 13:12:48 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 13:12:49 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-19 13:12:49 --> 404 Page Not Found: An-theme/ando
