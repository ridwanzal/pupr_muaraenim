<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-12-04 04:14:29 --> 404 Page Not Found: Img/pu.png
ERROR - 2018-12-04 04:14:29 --> 404 Page Not Found: Img/pu.png
ERROR - 2018-12-04 04:14:35 --> 404 Page Not Found: An-component/media
ERROR - 2018-12-04 04:21:29 --> Severity: error --> Exception: syntax error, unexpected 'AN_admin' (T_STRING) /opt/lampp/htdocs/dinaspu/application/controllers/AN_admin.php 4
ERROR - 2018-12-04 04:21:48 --> 404 Page Not Found: An-component/media
ERROR - 2018-12-04 04:24:43 --> 404 Page Not Found: An-component/media
ERROR - 2018-12-04 04:24:45 --> 404 Page Not Found: An-component/media
ERROR - 2018-12-04 04:25:38 --> 404 Page Not Found: An-component/media
ERROR - 2018-12-04 04:26:46 --> 404 Page Not Found: An-component/media
ERROR - 2018-12-04 04:26:48 --> 404 Page Not Found: An-component/media
ERROR - 2018-12-04 04:29:22 --> 404 Page Not Found: An-component/media
ERROR - 2018-12-04 04:30:32 --> 404 Page Not Found: An-component/media
ERROR - 2018-12-04 04:30:34 --> 404 Page Not Found: An-component/media
ERROR - 2018-12-04 04:30:48 --> Query error: Unknown column 'sesi_form' in 'field list' - Invalid query: INSERT INTO `foto_artikel` (`nama_foto`, `token_foto`, `sesi_form`, `id_user`) VALUES ('empat_tahun_jokowi-jk.jpg', NULL, NULL, NULL)
ERROR - 2018-12-04 04:39:44 --> Query error: Column 'kategori_id' cannot be null - Invalid query: INSERT INTO `bidang` (`bidang_id`, `kategori_id`, `bidang_judul`, `bidang_tugas`, `bidang_fungsi`, `bidang_isi`) VALUES (5080, NULL, 'Pembangunan Jalan Dan Jembatan', 'Bidang Pembangunan Jalan Dan Jembatan mempunyai tugas melaksanakan penyusunan dan pelaksanaan kebijakan di bidang perencanaan, pembangunan serta peningkatan jalan dan jembatan, pengendalian mutu dan hasil pelaksanaan pekerjaan.', 'Dalam menyelenggarakan tugas Bidang Pembangunan Jalan Dan Jembatan mempunyai fungsi : a. penyiapan bahan koordinasi penyusunan program kerja Bidang Pembangunan Jalan Dan Jembatan; b. pelaksanaan kegiatan teknis di bidang pembangunan jalan dan jembatan; c. pelaksanaan pembangunan dan peningkatan jalan serta jembatan; d. pelaksanaan dan penyusunan pengembangan jaringan jalan kabupaten, desa dan kota; e. pengoordinasian pemograman dan perencanaan teknik jalan, konektivitas sistem jaringan jalan dengan sistem moda transportasi bersama instansi terkait;  f. pelaksanaan pemutakhiran data dan penetapan peningkatan status fungsi jalan dan jembatan; g. pemantauan, pengendalian, evaluasi, dan pelaporan kegiatan Bidang Pembangunan Jalan Dan Jembatan;  h. pelaksanaan tugas lain yang diberikan oleh Kepala Dinas Pekerjaan Umum dan Penataan Ruang.', '&lt;p&gt; savavas&lt;/p&gt;')
ERROR - 2018-12-04 05:04:52 --> Query error: Column 'kategori_id' cannot be null - Invalid query: INSERT INTO `bidang` (`bidang_id`, `kategori_id`, `bidang_judul`, `bidang_tugas`, `bidang_fungsi`, `bidang_isi`) VALUES (6743, NULL, NULL, NULL, NULL, NULL)
ERROR - 2018-12-04 05:05:27 --> 404 Page Not Found: An-component/media
ERROR - 2018-12-04 05:25:21 --> Query error: Unknown column 'id' in 'order clause' - Invalid query: SELECT * FROM kategori WHERE aktif='Y' AND terhapus='N' ORDER BY id DESC
ERROR - 2018-12-04 05:25:47 --> Severity: Notice --> Undefined index: id /opt/lampp/htdocs/dinaspu/application/views/admin/galeri.php 145
ERROR - 2018-12-04 05:25:47 --> Severity: Notice --> Undefined index: id /opt/lampp/htdocs/dinaspu/application/views/admin/galeri.php 146
ERROR - 2018-12-04 05:25:47 --> Severity: Notice --> Undefined index: id /opt/lampp/htdocs/dinaspu/application/views/admin/galeri.php 145
ERROR - 2018-12-04 05:25:47 --> Severity: Notice --> Undefined index: id /opt/lampp/htdocs/dinaspu/application/views/admin/galeri.php 146
ERROR - 2018-12-04 05:25:47 --> Severity: Notice --> Undefined index: id /opt/lampp/htdocs/dinaspu/application/views/admin/galeri.php 145
ERROR - 2018-12-04 05:25:47 --> Severity: Notice --> Undefined index: id /opt/lampp/htdocs/dinaspu/application/views/admin/galeri.php 146
ERROR - 2018-12-04 05:25:47 --> Severity: Notice --> Undefined index: id /opt/lampp/htdocs/dinaspu/application/views/admin/galeri.php 145
ERROR - 2018-12-04 05:25:47 --> Severity: Notice --> Undefined index: id /opt/lampp/htdocs/dinaspu/application/views/admin/galeri.php 146
ERROR - 2018-12-04 05:25:47 --> Severity: Notice --> Undefined index: id /opt/lampp/htdocs/dinaspu/application/views/admin/galeri.php 145
ERROR - 2018-12-04 05:25:47 --> Severity: Notice --> Undefined index: id /opt/lampp/htdocs/dinaspu/application/views/admin/galeri.php 146
ERROR - 2018-12-04 05:25:47 --> Severity: Notice --> Undefined index: id /opt/lampp/htdocs/dinaspu/application/views/admin/galeri.php 145
ERROR - 2018-12-04 05:25:47 --> Severity: Notice --> Undefined index: id /opt/lampp/htdocs/dinaspu/application/views/admin/galeri.php 146
ERROR - 2018-12-04 05:25:47 --> Severity: Notice --> Undefined index: id /opt/lampp/htdocs/dinaspu/application/views/admin/galeri.php 145
ERROR - 2018-12-04 05:25:47 --> Severity: Notice --> Undefined index: id /opt/lampp/htdocs/dinaspu/application/views/admin/galeri.php 146
ERROR - 2018-12-04 05:25:47 --> Severity: Notice --> Undefined index: id /opt/lampp/htdocs/dinaspu/application/views/admin/galeri.php 145
ERROR - 2018-12-04 05:25:47 --> Severity: Notice --> Undefined index: id /opt/lampp/htdocs/dinaspu/application/views/admin/galeri.php 146
ERROR - 2018-12-04 05:25:47 --> Severity: Notice --> Undefined index: id /opt/lampp/htdocs/dinaspu/application/views/admin/galeri.php 145
ERROR - 2018-12-04 05:25:47 --> Severity: Notice --> Undefined index: id /opt/lampp/htdocs/dinaspu/application/views/admin/galeri.php 146
ERROR - 2018-12-04 05:25:49 --> Severity: Notice --> Undefined index: id /opt/lampp/htdocs/dinaspu/application/views/admin/galeri.php 145
ERROR - 2018-12-04 05:25:49 --> Severity: Notice --> Undefined index: id /opt/lampp/htdocs/dinaspu/application/views/admin/galeri.php 146
ERROR - 2018-12-04 05:25:49 --> Severity: Notice --> Undefined index: id /opt/lampp/htdocs/dinaspu/application/views/admin/galeri.php 145
ERROR - 2018-12-04 05:25:49 --> Severity: Notice --> Undefined index: id /opt/lampp/htdocs/dinaspu/application/views/admin/galeri.php 146
ERROR - 2018-12-04 05:25:49 --> Severity: Notice --> Undefined index: id /opt/lampp/htdocs/dinaspu/application/views/admin/galeri.php 145
ERROR - 2018-12-04 05:25:49 --> Severity: Notice --> Undefined index: id /opt/lampp/htdocs/dinaspu/application/views/admin/galeri.php 146
ERROR - 2018-12-04 05:25:49 --> Severity: Notice --> Undefined index: id /opt/lampp/htdocs/dinaspu/application/views/admin/galeri.php 145
ERROR - 2018-12-04 05:25:49 --> Severity: Notice --> Undefined index: id /opt/lampp/htdocs/dinaspu/application/views/admin/galeri.php 146
ERROR - 2018-12-04 05:25:49 --> Severity: Notice --> Undefined index: id /opt/lampp/htdocs/dinaspu/application/views/admin/galeri.php 145
ERROR - 2018-12-04 05:25:49 --> Severity: Notice --> Undefined index: id /opt/lampp/htdocs/dinaspu/application/views/admin/galeri.php 146
ERROR - 2018-12-04 05:25:49 --> Severity: Notice --> Undefined index: id /opt/lampp/htdocs/dinaspu/application/views/admin/galeri.php 145
ERROR - 2018-12-04 05:25:49 --> Severity: Notice --> Undefined index: id /opt/lampp/htdocs/dinaspu/application/views/admin/galeri.php 146
ERROR - 2018-12-04 05:25:49 --> Severity: Notice --> Undefined index: id /opt/lampp/htdocs/dinaspu/application/views/admin/galeri.php 145
ERROR - 2018-12-04 05:25:49 --> Severity: Notice --> Undefined index: id /opt/lampp/htdocs/dinaspu/application/views/admin/galeri.php 146
ERROR - 2018-12-04 05:25:49 --> Severity: Notice --> Undefined index: id /opt/lampp/htdocs/dinaspu/application/views/admin/galeri.php 145
ERROR - 2018-12-04 05:25:49 --> Severity: Notice --> Undefined index: id /opt/lampp/htdocs/dinaspu/application/views/admin/galeri.php 146
ERROR - 2018-12-04 05:25:49 --> Severity: Notice --> Undefined index: id /opt/lampp/htdocs/dinaspu/application/views/admin/galeri.php 145
ERROR - 2018-12-04 05:25:49 --> Severity: Notice --> Undefined index: id /opt/lampp/htdocs/dinaspu/application/views/admin/galeri.php 146
ERROR - 2018-12-04 05:25:50 --> 404 Page Not Found: An-component/media
ERROR - 2018-12-04 06:58:16 --> 404 Page Not Found: An-component/media
ERROR - 2018-12-04 06:58:25 --> 404 Page Not Found: An-component/media
ERROR - 2018-12-04 07:07:33 --> 404 Page Not Found: An-component/media
ERROR - 2018-12-04 07:07:34 --> 404 Page Not Found: An-component/media
ERROR - 2018-12-04 07:08:22 --> 404 Page Not Found: An-component/media
ERROR - 2018-12-04 07:12:51 --> 404 Page Not Found: An-component/media
ERROR - 2018-12-04 07:55:08 --> 404 Page Not Found: An-component/media
ERROR - 2018-12-04 07:55:12 --> 404 Page Not Found: An-component/media
ERROR - 2018-12-04 07:55:58 --> 404 Page Not Found: An-component/media
ERROR - 2018-12-04 07:57:05 --> 404 Page Not Found: An-component/media
ERROR - 2018-12-04 08:18:10 --> 404 Page Not Found: An-component/media
ERROR - 2018-12-04 08:42:20 --> 404 Page Not Found: An-component/media
ERROR - 2018-12-04 08:42:21 --> 404 Page Not Found: An-component/media
ERROR - 2018-12-04 08:44:44 --> 404 Page Not Found: An-component/media
ERROR - 2018-12-04 08:44:53 --> 404 Page Not Found: Img/pu.png
ERROR - 2018-12-04 08:45:11 --> 404 Page Not Found: An-theme/admin
ERROR - 2018-12-04 08:56:21 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-04 08:57:07 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-04 08:58:34 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-04 09:00:06 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-04 09:00:28 --> 404 Page Not Found: An-theme/ando
ERROR - 2018-12-04 09:00:32 --> 404 Page Not Found: An-theme/ando
