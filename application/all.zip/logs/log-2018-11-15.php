<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-11-15 06:48:39 --> Severity: error --> Exception: syntax error, unexpected '/' /opt/lampp/htdocs/dinaspu/application/views/ando/footer.php 226
ERROR - 2018-11-15 06:54:10 --> Severity: error --> Exception: Call to undefined function assets_url() /opt/lampp/htdocs/dinaspu/application/views/admin/login.php 33
ERROR - 2018-11-15 06:54:29 --> 404 Page Not Found: Img/pu.png
ERROR - 2018-11-15 06:54:49 --> 404 Page Not Found: Img/pu.png
ERROR - 2018-11-15 06:56:55 --> 404 Page Not Found: Img/pu.png
ERROR - 2018-11-15 07:24:19 --> Severity: error --> Exception: syntax error, unexpected '/' /opt/lampp/htdocs/dinaspu/application/views/ando/footer.php 226
