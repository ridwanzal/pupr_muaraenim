<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-11-19 04:53:25 --> 404 Page Not Found: Kontak/index
ERROR - 2018-11-19 05:27:04 --> 404 Page Not Found: Img/pu.png
ERROR - 2018-11-19 05:27:05 --> 404 Page Not Found: Img/pu.png
