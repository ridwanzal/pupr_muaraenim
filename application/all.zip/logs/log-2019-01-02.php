<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-01-02 16:17:04 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'puprmuar_dpu'@'localhost' (using password: YES) /home/u164602079/public_html/dinaspu/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2019-01-02 16:17:04 --> Unable to connect to the database
ERROR - 2019-01-02 16:17:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2019-01-02 16:18:10 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-01-02 16:18:11 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-01-02 16:18:11 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-01-02 16:18:25 --> 404 Page Not Found: An-theme/ando
ERROR - 2019-01-02 16:18:25 --> 404 Page Not Found: An-theme/ando
