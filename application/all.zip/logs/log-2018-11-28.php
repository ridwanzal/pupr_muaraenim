<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-11-28 03:16:29 --> 404 Page Not Found: Img/pu.png
ERROR - 2018-11-28 03:29:47 --> Query error: Column 'page_isi' cannot be null - Invalid query: INSERT INTO `pages` (`page_judul`, `page_url`, `page_isi`, `page_foto`, `page_javascript`, `page_status`, `page_created`, `page_meta_keywords`, `page_meta_description`, `page_id_user`) VALUES ('judul', 'ahdhd', NULL, 'http://localhost/dinaspu/an-component/media/upload-gambar-pendukung/sparkler-677774_1280.jpg', '', 'published', '2018:11:28 09:29:47', 'keywoard', 'meta', '1')
ERROR - 2018-11-28 03:34:42 --> Query error: Unknown column 'page_judul' in 'field list' - Invalid query: INSERT INTO `bidang` (`page_judul`, `bidang_url`, `bidang_tugas`, `bidang_fungsi`, `bidang_isi`, `bidang_foto`, `bidang_javascript`, `bidang_status`, `bidang_created`, `bidang_meta_keywords`, `bidang_meta_description`, `bidang_id_user`) VALUES ('judul bidang', 'gunsig', NULL, NULL, NULL, 'http://localhost/dinaspu/an-component/media/upload-gambar-pendukung/sparkler-677774_1280.jpg', '', 'published', '2018:11:28 09:34:42', 'meta key', 'meta', '1')
ERROR - 2018-11-28 04:33:38 --> 404 Page Not Found: AN_admin/gea
ERROR - 2018-11-28 04:33:39 --> 404 Page Not Found: AN_admin/fea
ERROR - 2018-11-28 04:33:41 --> 404 Page Not Found: AN_admin/featurde
ERROR - 2018-11-28 07:02:03 --> 404 Page Not Found: Ajax_admin/page
ERROR - 2018-11-28 07:03:29 --> 404 Page Not Found: Ajax_admin/bidang
ERROR - 2018-11-28 07:03:40 --> 404 Page Not Found: An_ajax_admin/bidang
ERROR - 2018-11-28 07:48:13 --> Query error: Unknown column 'id_bidang' in 'field list' - Invalid query: INSERT INTO `bidang` (`id_bidang`, `fungsi_bidang`, `isi_bidang`) VALUES (NULL, NULL, NULL)
ERROR - 2018-11-28 07:50:02 --> Query error: Unknown column 'id_bidang' in 'field list' - Invalid query: INSERT INTO `bidang` (`id_bidang`, `fungsi_bidang`, `isi_bidang`) VALUES (NULL, 'fungsi bidang', NULL)
ERROR - 2018-11-28 07:52:34 --> Query error: Column 'bidang_isi' cannot be null - Invalid query: INSERT INTO `bidang` (`bidang_id`, `bidang_fungsi`, `bidang_isi`) VALUES (NULL, 'fungsi bidang', NULL)
ERROR - 2018-11-28 08:04:35 --> 404 Page Not Found: Bidang/276-
